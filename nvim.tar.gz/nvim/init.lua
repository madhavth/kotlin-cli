-- bootstrap lazy.nvim, LazyVim and your plugins
require("config.lazy")

vim.g.animate = false

-- Disable system clipboard for deleting text
vim.cmd("set clipboard-=unnamedplus")
